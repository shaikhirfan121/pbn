package pbn.train;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;

public class Splash_Screen extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash__screen);
		
		Thread background=new Thread(){
			public void run(){
				try {
				sleep(2*1000);
						Intent i=new Intent(Splash_Screen.this, MainActivity.class);
				startActivity(i);
				finish();
				} catch(Exception e) {
			}
			}
		};
		
	background.start();	
	}
}


	

