package pbn.train;

import java.io.IOException;

import android.os.Bundle;
import android.app.Activity;
import android.app.Dialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	TextView action_about,t1;

	public RadioGroup redogroup;
	public RadioButton redioButton,b1,b2;
	public Button btnchange,pbntoawb,pbntoned,pbntoparli;
	SQLiteDatabase db;
	String checkstring, H="Hindi",E="English";
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		db=openOrCreateDatabase("Language_manage", Context.MODE_PRIVATE, null);
		db.execSQL("CREATE TABLE IF NOT EXISTS LanguageTable(name VARCHAR);");
			
		Cursor c=db.rawQuery("SELECT * FROM LanguageTable", null);
		if(c.getCount()==0)
		{
			db.execSQL("INSERT INTO LanguageTable VALUES('Hindi');");
			return;
		}
		StringBuffer buffer=new StringBuffer();
		while(c.moveToNext())
		{
			buffer.append("Language:"+c.getString(0)+"\n");
			checkstring=(c.getString(0).toString());
		}
		pbntoawb = (Button) findViewById(R.id.button1);
		pbntoned= (Button) findViewById(R.id.button2);
		pbntoparli= (Button) findViewById(R.id.button3);
		b1= (RadioButton) findViewById(R.id.radioEnglish);
		b2= (RadioButton) findViewById(R.id.radioHindi);
		if(checkstring.equals(H)){
			pbntoawb.setText("औरंगाबाद जाने के लिए ट्रेन");
			pbntoned.setText("नांदेड़  जाने के लिए ट्रेन");
			pbntoparli.setText("परली जाने के लिए ट्रेन");
			}
		if(checkstring.equals(E)){
			pbntoawb.setText("AURANGABAD ROUT");
			pbntoned.setText("NANDED ROUTE");
			pbntoparli.setText("PARLI ROUTE");
			
			}

	}
	public void OnClickButton(View v) {
		Intent i = new Intent(this, ReadData.class);
		
		switch (v.getId()) {
		case R.id.button1:
			i.putExtra("chapter", "one");
			startActivity(i);
			break;
		case R.id.button2:
			i.putExtra("chapter", "two");
			startActivity(i);
			break;
		case R.id.button3:
			i.putExtra("chapter", "three");
			startActivity(i);
			break;
		case R.id.button4:
			i.putExtra("chapter", "four");
			startActivity(i);
			break;
		default:
			break;

		}
	}
	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
	 @Override
	  public boolean onOptionsItemSelected(MenuItem item) {
	    switch (item.getItemId()) {
	    // action with ID action_refresh was selected
	    case R.id.action_about:
	      Toast.makeText(this, "THANX", Toast.LENGTH_LONG).show();
	      
	      aboutMethod(action_about);
	      break;
	    default:
	      break;
	    }

	    return true;
	  } 
	public void aboutMethod(View v){
		
		final Dialog dialog = new Dialog(MainActivity.this);
		dialog.setTitle("Select Language");
		dialog.setContentView(R.layout.dialog_view);
	
		action_about = (TextView) dialog.findViewById(R.id.action_about);
		action_about.setText("\t\nshaikh irfan \t\nMOB:  8180898771\t\nEmail:  shaikhirfan121@gmail.com\nThanx for download this Application");
		
		dialog.show();
		redogroup = (RadioGroup) dialog.findViewById(R.id.radioGroup);
		btnchange = (Button) dialog.findViewById(R.id.btnChange);
		
		btnchange.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				// get selected radio button from radioGroup
				int selectedId = redogroup.getCheckedRadioButtonId();
				
				// find the radiobutton by returned id
				redioButton = (RadioButton) dialog.findViewById(selectedId);
				
				Toast.makeText(MainActivity.this,redioButton.getText(), Toast.LENGTH_SHORT).show();
				/*
				db.execSQL("INSERT INTO LanguageTable VALUES('"+redioButton.getText()+"');");
	    		showMessage("Success", "Record added successfully");
				*/
				Cursor c=db.rawQuery("SELECT * FROM LanguageTable WHERE name='English' "+" OR "+" name='Hindi'", null);
	    		if(c.moveToFirst())
	    		{
	    			db.execSQL("UPDATE LanguageTable SET name='"+redioButton.getText()+"'");	    			
	    			showMessage("Success", "Language is change");
	    			
	    		}
	    		else
	    		{
	    			showMessage("Error", "Invalid Language");
	    		}
				 
				/*
				Cursor c=db.rawQuery("SELECT * FROM LanguageTable WHERE name='English'", null);
	    		if(c.moveToFirst())
	    		{
	    			db.execSQL("DELETE FROM LanguageTable WHERE name='English'");
	    			showMessage("Success", "Record Deleted");
	    		}
	    		else
	    		{
	    			showMessage("Error", "Invalid Rollno");
	    		}*/

					// TODO Auto-generated method stub
				
				/*
					Cursor c=db.rawQuery("SELECT * FROM LanguageTable", null);
		    		if(c.getCount()==0)
		    		{
		    			showMessage("Error", "No records found");
		    			return;
		    		}
		    		StringBuffer buffer=new StringBuffer();
		    		while(c.moveToNext())
		    		{
		    			buffer.append("Name: "+c.getString(0)+"\n");
		    		}
		    		showMessage("Student Details", buffer.toString());
		    		*/
				}
			
			

		});	
	
	}
	public void showMessage(String title,String message)
    {
		// Refresh main activity upon close of dialog box
		Intent refresh = new Intent(this, MainActivity.class);
		startActivity(refresh);
		this.finish(); //
    	Builder builder=new Builder(this);
    	builder.setCancelable(true);
    	builder.setTitle(title);
    	builder.setMessage(message);
    	builder.show();
	}
}
