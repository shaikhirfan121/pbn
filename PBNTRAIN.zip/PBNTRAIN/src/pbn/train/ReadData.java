package pbn.train;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class ReadData extends Activity {
	String fileName,l, H="Hindi",E="English";
	SQLiteDatabase db;
	TextView DisplayTrain;
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.datadisplay);
		db=openOrCreateDatabase("Language_manage", Context.MODE_PRIVATE, null);
		db.execSQL("CREATE TABLE IF NOT EXISTS LanguageTable(name VARCHAR);");
		DisplayTrain = (TextView) findViewById(R.id.txt1);
		// TODO Auto-generated method stub
					Cursor c=db.rawQuery("SELECT * FROM LanguageTable", null);
		    		if(c.getCount()==0)
		    		{
		    			showMessage("Error", "NOT SELECTED ANY LANGUAGE");
		    			return;
		    		}
		    		StringBuffer buffer=new StringBuffer();
		    		while(c.moveToNext())
		    		{
		    			buffer.append("Language:"+c.getString(0)+"\n");
		    			l=(c.getString(0).toString());
		    		}
		Intent i1 = getIntent();
		
		fileName = i1.getStringExtra("chapter");
		
		if(fileName.equals("one")) {
			try {
				showFileOne();
			} catch (IOException e) {
				Toast.makeText(getApplicationContext(),"Problems: " + e.getMessage(), Toast.LENGTH_LONG).show();
			}
		}

		if(fileName.equals("two")){
			try {
				showFileTwo();
			} catch (IOException e) {
				Toast.makeText(getApplicationContext(),"Problems: " + e.getMessage(), Toast.LENGTH_LONG).show();
			}
		}	
		

	if(fileName.equals("three")) {
		try {
			showFileThree();
		} catch (IOException e) {
			Toast.makeText(getApplicationContext(),"Problems: " + e.getMessage(), Toast.LENGTH_LONG).show();
		}
	}
	
	if(fileName.equals("four")) {
		try {
			showFilefour();
		} catch (IOException e) {
			Toast.makeText(getApplicationContext(),"Problems: " + e.getMessage(), Toast.LENGTH_LONG).show();
		}
	}
	
	}

	public void showFileOne() throws IOException {
		String str = "";
		StringBuffer buf = new StringBuffer();
		if(l.equals(E)){
			InputStream is = this.getResources().openRawResource(R.raw.pbn_to_awb_english);
			BufferedReader reader = new BufferedReader(new InputStreamReader(is));
			if (is != null) {
				while ((str = reader.readLine()) != null) {
					buf.append(str + "\n");
				}
			}
			is.close();
		}
		else{
			InputStream is = this.getResources().openRawResource(R.raw.pbn_to_awb_hindi);
			BufferedReader reader = new BufferedReader(new InputStreamReader(is));
			if (is != null) {
				while ((str = reader.readLine()) != null) {
					buf.append(str + "\n");
				}
			}
			is.close();
		}		
		Typeface custom_font = Typeface.createFromAsset(getAssets(),"fonts/comic.ttf");
		DisplayTrain.setTypeface(custom_font);
		DisplayTrain.setText(buf.toString());
	}

	public void showFileTwo() throws IOException {
		String str = "";
		StringBuffer buf = new StringBuffer();
		if(l.equals(E)){
			InputStream is = this.getResources().openRawResource(R.raw.pbn_to_nanded_english);
			BufferedReader reader = new BufferedReader(new InputStreamReader(is));
			if (is != null) {
				while ((str = reader.readLine()) != null) {
					buf.append(str + "\n");
				}
			}
			is.close();
		}
		else{
			InputStream is = this.getResources().openRawResource(R.raw.pbn_to_nanded_hindi);
			BufferedReader reader = new BufferedReader(new InputStreamReader(is));
			if (is != null) {
				while ((str = reader.readLine()) != null) {
					buf.append(str + "\n");
				}
			}
			is.close();
		}	
		Typeface custom_font = Typeface.createFromAsset(getAssets(),"fonts/comic.ttf");
		DisplayTrain .setTypeface(custom_font);    
		DisplayTrain.setText(buf.toString());

	}
	
	
	
	
	
	
	
	
public void showFileThree() throws IOException {
	String str = "";
	StringBuffer buf = new StringBuffer();
	if(l.equals(E)){
	InputStream is = this.getResources().openRawResource(R.raw.pbn_to_parli_english);
	BufferedReader reader = new BufferedReader(new InputStreamReader(is));
	if (is != null) {
		while ((str = reader.readLine()) != null) {
			buf.append(str + "\n");
		}
	}
	is.close();
	}
	else{
		InputStream is = this.getResources().openRawResource(R.raw.pbn_to_parli_hindi);
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		if (is != null) {
			while ((str = reader.readLine()) != null) {
				buf.append(str + "\n");
			}
		}
		is.close();
	}
	 Typeface custom_font = Typeface.createFromAsset(getAssets(),"fonts/comic.ttf");
	 DisplayTrain.setTypeface(custom_font);
     
      DisplayTrain.setText(buf.toString());
		}

public void showFilefour() throws IOException {
	String str = "";
	StringBuffer buf = new StringBuffer();
	InputStream is = this.getResources().openRawResource(R.raw.parbhaniinformation);
	BufferedReader reader = new BufferedReader(new InputStreamReader(is));
	if (is != null) {
		while ((str = reader.readLine()) != null) {
			buf.append(str + "\n");
		}
	}
	is.close();
	TextView t1 = (TextView) findViewById(R.id.txt1);
	 Typeface custom_font = Typeface.createFromAsset(getAssets(),"fonts/comic.ttf");
      t1.setTypeface(custom_font);
     
	t1.setText(buf.toString());
		}
	public void showMessage(String title,String message)
    {
    	Builder builder=new Builder(this);
    	builder.setCancelable(true);
    	builder.setTitle(title);
    	builder.setMessage(message);
    	builder.show();
	}
}